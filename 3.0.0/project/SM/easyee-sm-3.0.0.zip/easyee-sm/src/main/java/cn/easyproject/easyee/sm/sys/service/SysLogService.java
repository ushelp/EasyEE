package cn.easyproject.easyee.sm.sys.service;

import cn.easyproject.easyee.sm.base.pagination.PageBean;
import cn.easyproject.easyee.sm.sys.criteria.SysLogCriteria;
import cn.easyproject.easyee.sm.sys.entity.SysLog;

public interface SysLogService {
	public void add(SysLog sysLog);
	@SuppressWarnings("rawtypes")
	public void findByPage(PageBean pb,SysLogCriteria sysLogCriteria);
}
