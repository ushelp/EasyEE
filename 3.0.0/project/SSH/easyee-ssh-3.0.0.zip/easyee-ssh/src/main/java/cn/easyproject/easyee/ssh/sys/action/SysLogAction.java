package cn.easyproject.easyee.ssh.sys.action;


import cn.easyproject.easyee.ssh.sys.criteria.SysLogCriteria;
import cn.easyproject.easyee.ssh.sys.service.SysLogService;
import cn.easyproject.easyee.ssh.base.action.BaseAction;
import cn.easyproject.easyee.ssh.base.util.PageBean;

public class SysLogAction extends BaseAction{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private SysLogService sysLogService;
	private SysLogCriteria sysLogCriteria;
	
	
	/**
	 * 分页查询
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public String list() throws Exception {
		
		if (!isNotNullAndEmpty(sort)) {
			sort="logTime";
		}
		if (!isNotNullAndEmpty(order)) {
			order="desc";
		}
		
		
		PageBean pb = super.getPageBean(); // 获得分页对象
		pb.setSort(sort);
		pb.setSortOrder(order);
		sysLogService.findByPage(pb, sysLogCriteria);

		super.setJsonPaginationMap(pb);
		return JSON;
	}
	
	public SysLogCriteria getSysLogCriteria() {
		return sysLogCriteria;
	}
	public void setSysLogCriteria(SysLogCriteria sysLogCriteria) {
		this.sysLogCriteria = sysLogCriteria;
	}
	public void setSysLogService(SysLogService sysLogService) {
		this.sysLogService = sysLogService;
	}
	
	
	
}
