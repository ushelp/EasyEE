package cn.easyproject.easyee.ssh.module.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import cn.easyproject.easyee.ssh.module.criteria.DeptCriteria;
import cn.easyproject.easyee.ssh.module.entity.Dept;
import cn.easyproject.easyee.ssh.module.service.DeptService;
import cn.easyproject.easyee.ssh.base.service.BaseService;
import cn.easyproject.easyee.ssh.base.util.PageBean;

/**
 * 业务实现类统一继承BaseService类
 * BaseService中注入了通用DAO，直接调用commonDAO的数据方法方法即可
 * 
 * @author easyproject.cn
 * @version 1.0
 *
 */
@Service("deptService")
public class DeptServiceImpl extends BaseService implements DeptService {

	@Override
	public void add(Dept dept) {
		commonDAO.save(dept);
	}

	@Override
	public void delete(Integer deptno) {
		commonDAO.updateByHql("delete from Dept where deptno=?",deptno);
	}

	@Override
	public void update(Dept dept) {
		commonDAO.update(dept);
	}

	@Override
	public Dept get(Integer deptno) {
		return commonDAO.get(Dept.class, deptno);
	}

	@Override
	public void findByPage(PageBean pageBean, DeptCriteria deptCriteria) {
		pageBean.setEntityName("Dept dept");
		pageBean.setSelect("select dept");
		
		// 按条件分页查询
		commonDAO.findByPage(pageBean,deptCriteria);
	}

	@Override
	public int findMaxPage(int rowPerPage) {
		return (commonDAO.findMaxPage("select count(*) from Dept", rowPerPage)-1)/rowPerPage+1;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Dept> findAll() {
		return commonDAO.find("from Dept");
	}

}
