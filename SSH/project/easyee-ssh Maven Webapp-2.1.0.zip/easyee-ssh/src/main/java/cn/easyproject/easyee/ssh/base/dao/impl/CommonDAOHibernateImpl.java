package cn.easyproject.easyee.ssh.base.dao.impl;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.jdbc.Work;
import org.hibernate.transform.ResultTransformer;
import org.springframework.orm.hibernate5.HibernateCallback;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import cn.easyproject.easyee.ssh.base.dao.CommonDAO;
import cn.easyproject.easyee.ssh.base.util.EasyCriteria;
import cn.easyproject.easyee.ssh.base.util.PageBean;

/**
 * 
 * @author easyproject.cn
 * @version 1.0
 * 
 */
@Repository("commonDAOHibernateImpl")
@SuppressWarnings({ "rawtypes", "unchecked" })
public class CommonDAOHibernateImpl extends HibernateDaoSupport implements
		CommonDAO {
	

	@Resource(name = "sessionFactory")
	private SessionFactory mySessionFacotry;

	@PostConstruct
	public void injectSessionFactory() {
		super.setSessionFactory(mySessionFacotry);
	}

	@Override
	public <T> T get(Class clazz, Serializable id) {
		return (T) getHibernateTemplate().get(clazz, id);
	}

	@Override
	public Serializable save(Object o) {
		return getHibernateTemplate().save(o);
	}

	@Override
	public void delete(Class clazz, Serializable id) {
		getHibernateTemplate().delete(getHibernateTemplate().get(clazz, id));
	}

	@Override
	public void delete(Object o) {
		getHibernateTemplate().delete(o);
	}

	@Override
	public Integer deleteByValues(Class cls, String idFieldName,
			String valuesList) {
		try {
			valuesList = valuesList == null ? "" : valuesList.trim();
			if ("".equals(valuesList)) {
				return 0;
			} else {
				valuesList = "'" + valuesList.replaceAll(",", "','") + "'";
			}
			final String hql = "delete from " + cls.getSimpleName() + " where "
					+ idFieldName + " in(" + valuesList + ")";
			return (Integer) getHibernateTemplate().execute(
					new HibernateCallback() {
						public Object doInHibernate(Session session)
								throws HibernateException {
							return session.createQuery(hql).executeUpdate();
						}
					});
		} catch (RuntimeException e) {
			throw e;
		}
	}
	

	@Override
	public void deleteCascadeByValues(Class cls, String idFieldName, String valuesList) {
		valuesList = valuesList == null ? "" : valuesList.trim();
		if (!("".equals(valuesList))) {
			String hql = "from " + cls.getSimpleName() + " where "
					+ idFieldName + " in(" + valuesList + ")";
			for (Object o : getHibernateTemplate().find(hql)) {
				getHibernateTemplate().delete(o);
			}
		}
	}

	@Override
	public void update(Object o) {
		getHibernateTemplate().update(o);
	}

	@Override
	public List findAll(Class cls) {
		try {
			String queryString = "from " + cls.getName();
			List list = getHibernateTemplate().find(queryString);
			initialize(list);
			return list;
		} catch (RuntimeException re) {
			throw re;
		}
	}

	@Override
	public List find(String hql, Object... values) {
		return getHibernateTemplate().find(hql, values);
	}
	
	@Override
	public List find(String hql,EasyCriteria easyCriteria){
		if(easyCriteria!=null){
			return getHibernateTemplate().find(hql+" "+easyCriteria.getCondition(), easyCriteria.getValues());
		}else{
			return getHibernateTemplate().find(hql);
		}
	}

	@Override
	public List findByProperty(Class cls, String propertyName, Object value) {
		try {
			String queryString = "from " + cls.getName()
					+ " as model where model." + propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			throw re;
		}
	}

	@Override
	public List findByPropertyIgnoreCase(Class cls, String propertyName,
			String value) {
		try {
			String queryString = "from " + cls.getName()
					+ " as model where lower(model." + propertyName + ")= ?";
			return getHibernateTemplate()
					.find(queryString, value.toLowerCase());
		} catch (RuntimeException re) {
			throw re;
		}
	}

	@Override
	public List findNamedQuery(final String name, final Object... values) {

		return super.getHibernateTemplate().execute(
				new HibernateCallback<List>() {

					@Override
					public List doInHibernate(Session session)
							throws HibernateException {
						List retList = null;
						if (name == null || "".equals(name.trim())) {
							return retList;
						}
						Query query = session.getNamedQuery(name.trim());
						if (values != null) {
							for (int i = 0; i < values.length; i++) {
								query.setParameter(i, values[i]);
							}
						}
						retList = query.list();
						return retList;
					}

				});

	}


	@Override
	public void findByPage(final PageBean pageBean, final List values) {
		final String hql = pageBean.getHql() != null ? pageBean.getHql()
				: pageBean.getAutoHql();
		this.getHibernateTemplate().execute(new HibernateCallback<Object>() {
			@Override
			public Object doInHibernate(Session session)
					throws HibernateException {
				
				Query query = session.createQuery(hql);
				query.setFirstResult(pageBean.getRowStart());
				query.setMaxResults(pageBean.getRowsPerPage());
				if (values != null) {
					for (int i = 0; i < values.size(); i++) {
						query.setParameter(i, values.get(i));
					}
				}
				
				List res = query.list();
				
				// System.out.println(res.get(0) instanceof HibernateProxy);
				
				pageBean.setData(res);
				String queryString = "";
				int end = hql.length();
				if (hql.indexOf("order by") != -1) {
					end = hql.indexOf("order by");
				}
				if (hql.toUpperCase().indexOf("SELECT") != -1) {
					int i = query.getQueryString().toUpperCase()
							.indexOf("FROM");
					queryString = "select count(*) " + hql.substring(i, end);
				} else {
					queryString = "select count(*) " + hql.substring(0, end);
				}
				
				// 去掉ORDER BY 的部分
				int j = queryString.toUpperCase().lastIndexOf("ORDER");
				if (j != -1) {
					queryString = queryString.substring(0, j);
				}
				Query cquery = session.createQuery(queryString);
				if (values != null) {
					for (int i = 0; i < values.size(); i++) {
						cquery.setParameter(i, values.get(i));
					}
				}
				int maxRow = (Integer.valueOf(cquery.iterate().next()
						.toString())).intValue();
				pageBean.setRowsCount(maxRow);
				
				return pageBean;
			}
		});
		
	}
	@Override
	public void findByPage(final PageBean pageBean) {
		this.findByPage(pageBean,new ArrayList());
	}
	@Override
	public void findByPage(PageBean pageBean, EasyCriteria easyCriteria) {
		if(easyCriteria!=null){
			pageBean.setCondition(easyCriteria.getCondition());
			this.findByPage(pageBean,easyCriteria.getValues());
		}else{
			this.findByPage(pageBean);
		}
	}

	@Override
	public int findCount(String hql, Object... values) {
		return Integer.valueOf(this.getHibernateTemplate().find(hql, values)
				.get(0).toString());
	}
	@Override
	public int findCount(String hql,EasyCriteria easyCriteria) {
		if(easyCriteria!=null){
			return Integer.valueOf(this.getHibernateTemplate().find(hql+" "+easyCriteria.getCondition(), easyCriteria.getValues())
				.get(0).toString());
		}
		return Integer.valueOf(this.getHibernateTemplate().find(hql).toString());
	}

	@Override
	public List findTop(final String hql, final int topCount,
			final Object... values) {
		List list = getHibernateTemplate().execute(
				new HibernateCallback<List>() {
					public List doInHibernate(Session session)
							throws HibernateException {
						Query query = session.createQuery(hql);
						query.setFirstResult(0);
						query.setMaxResults(topCount);
						if (values != null && values.length > 0) {
							for (int i = 0; i < values.length; i++) {
								query.setParameter(i, values[i]);
							}
						}

						List ret = query.list();
						return ret;
					}
				});

		return list;
	}
	@Override
	public List findTop(final String hql,final int topCount, final EasyCriteria easyCriteria){
		
		List list = getHibernateTemplate().execute(
				new HibernateCallback<List>() {
					public List doInHibernate(Session session)
							throws HibernateException {
						String hql2=hql;
						if(easyCriteria!=null){
							hql2=hql+" "+easyCriteria.getCondition();
						}
						Query query = session.createQuery(hql2);
						query.setFirstResult(0);
						query.setMaxResults(topCount);
						if(easyCriteria!=null){
							Object[] values=easyCriteria.getValues().toArray();
							if (values != null && values.length > 0) {
								for (int i = 0; i < values.length; i++) {
									query.setParameter(i, values[i]);
								}
							}
						}
						
						List ret = query.list();
						return ret;
					}
				});
		
		return list;
	}

	@Override
	public List findByCache(String hql, Object... values) {
		getHibernateTemplate().setCacheQueries(true);
		if (null != DEFAULTQUERYCACHEREGION
				|| (!"".equals(DEFAULTQUERYCACHEREGION))) {
			getHibernateTemplate().setQueryCacheRegion(DEFAULTQUERYCACHEREGION);
		}
		List ret = super.getHibernateTemplate().find(hql, values);
		getHibernateTemplate().setCacheQueries(false);// 用完后立即关闭，防止其他查询被缓存
		return ret;
	}
	@Override
	public List findByCache(String hql, EasyCriteria easyCriteria){
		getHibernateTemplate().setCacheQueries(true);
		if (null != DEFAULTQUERYCACHEREGION
				|| (!"".equals(DEFAULTQUERYCACHEREGION))) {
			getHibernateTemplate().setQueryCacheRegion(DEFAULTQUERYCACHEREGION);
		}
		List ret=new ArrayList();
		if(easyCriteria!=null){
			ret = super.getHibernateTemplate().find(hql+" "+easyCriteria.getCondition(), easyCriteria.getValues());
		}else{
			ret = super.getHibernateTemplate().find(hql);
		}
		getHibernateTemplate().setCacheQueries(false);// 用完后立即关闭，防止其他查询被缓存
		return ret;
	}

	@Override
	public List findByCache(String hql, String queryCacheRegion,
			Object... values) {
		getHibernateTemplate().setCacheQueries(true); // 开启
		getHibernateTemplate().setQueryCacheRegion(queryCacheRegion);
		List ret = super.getHibernateTemplate().find(hql, values);
		getHibernateTemplate().setCacheQueries(false);// 用完后立即关闭，防止其他查询被缓存
		return ret;
	}
	
	@Override
	public List findByCache(String hql, String queryCacheRegion, EasyCriteria easyCriteria){
		getHibernateTemplate().setCacheQueries(true); // 开启
		getHibernateTemplate().setQueryCacheRegion(queryCacheRegion);
		List ret=new ArrayList();
		if(easyCriteria!=null){
			ret = super.getHibernateTemplate().find(hql+" "+easyCriteria.getCondition(), easyCriteria.getValues());
		}else{
			ret = super.getHibernateTemplate().find(hql);
		}
		return ret;
	}

	@Override
	public int updateByHql(String hql, Object... values) {
		return this.getHibernateTemplate().bulkUpdate(hql, values);
	}

	@Override
	public List findBySQL(String sql, Class c, Object... values) {
		final String v_sql = sql;
		final Class v_c = c;
		final Object[] vs = values;
		List list = this.getHibernateTemplate().execute(
				new HibernateCallback<List>() {

					public List doInHibernate(Session session)
							throws HibernateException {
						SQLQuery query = session.createSQLQuery(v_sql);
						if (vs != null && vs.length > 0) {
							for (int i = 0; i < vs.length; i++) {
								query.setParameter(i, vs[i]);
							}
						}
						List ret = query.addEntity(v_c).list();
						return ret;
					}

				});
		return list;
	}
	
	public List findBySQL(String sql,ResultTransformer transformers, Object... values){
		final String v_sql = sql;
		final Object[] vs = values;
		final ResultTransformer t  = transformers;
		List list = this.getHibernateTemplate().execute(
				new HibernateCallback<List>() {
					public List doInHibernate(Session session)
							throws HibernateException {
						SQLQuery query = session.createSQLQuery(v_sql);
						if (vs != null && vs.length > 0) {
							for (int i = 0; i < vs.length; i++) {
								query.setParameter(i, vs[i]);
							}
						}
						query.setResultTransformer(t);
						List ret = query.list();
						return ret;
					}

				});
		return list;
	}
	public List findBySQL(final String sql,ResultTransformer transformers,final EasyCriteria easyCriteria){
		
		final ResultTransformer t  = transformers;
		List list = this.getHibernateTemplate().execute(
				new HibernateCallback<List>() {
					public List doInHibernate(Session session)
							throws HibernateException {
						String v_sql = sql;
						Object[] vs = null;
						if(easyCriteria!=null){
							v_sql = sql+" "+easyCriteria.getCondition();
							vs = easyCriteria.getValues().toArray();
						}
						
						SQLQuery query = session.createSQLQuery(v_sql);
						if (vs != null && vs.length > 0) {
							for (int i = 0; i < vs.length; i++) {
								query.setParameter(i, vs[i]);
							}
						}
						query.setResultTransformer(t);
						List ret = query.list();
						return ret;
					}
					
				});
		return list;
	}

	@Override
	public List findBySQL(String sql, Object... values) {
		final String v_sql = sql;
		final Object[] vs = values;
		List list = this.getHibernateTemplate().execute(
				new HibernateCallback<List>() {

					public List doInHibernate(Session session)
							throws HibernateException {
						SQLQuery query = session.createSQLQuery(v_sql);
						if (vs != null && vs.length > 0) {
							for (int i = 0; i < vs.length; i++) {
								query.setParameter(i, vs[i]);
							}
						}
						List ret = query.list();
						return ret;
					}

				});
		return list;
	}
	@Override
	public List findBySQL(final String sql,final EasyCriteria easyCriteria) {
		List list = this.getHibernateTemplate().execute(
				new HibernateCallback<List>() {
					
					public List doInHibernate(Session session)
							throws HibernateException {
						
						String v_sql = sql;
						Object[] vs = null;
						if(easyCriteria!=null){
							v_sql = sql+" "+easyCriteria.getCondition();
							vs = easyCriteria.getValues().toArray();
						}
						
						SQLQuery query = session.createSQLQuery(v_sql);
						if (vs != null && vs.length > 0) {
							for (int i = 0; i < vs.length; i++) {
								query.setParameter(i, vs[i]);
							}
						}
						List ret = query.list();
						return ret;
					}
					
				});
		return list;
	}
	

	@Override
	public void updateBySQL(String sql, Object... values) {
		final String e_sql = sql;
		final Object[] vs = values;
		getHibernateTemplate().executeWithNativeSession(
				new HibernateCallback<Boolean>() {

					public Boolean doInHibernate(Session session)
							throws HibernateException {
						Transaction tx = session.beginTransaction();
						SQLQuery sq = session.createSQLQuery(e_sql);
						if (vs != null && vs.length > 0) {
							for (int i = 0; i < vs.length; i++) {
								sq.setParameter(i, vs[i]);
							}
						}
						sq.executeUpdate();
						tx.commit();
						if (session.isOpen()) {
							session.close();
						}
						return true;
					}
				});

	}

	@Override
	public void batchUpdateSQL(final String sql, final Object[][] values) {

		Session session = this.getSessionFactory().openSession();
		session.doWork(new Work() {
			public void execute(Connection connection) throws SQLException {
				PreparedStatement pstmt = null;
				try {

					connection.setAutoCommit(false);// 手动提交
					pstmt = connection.prepareStatement(sql);// 预编译

					for (Object[] row : values) {
						for (int i = 0; i < row.length; i++) {
							pstmt.setObject(i + 1, row[i]);
						}
						pstmt.addBatch();
					}
					pstmt.executeBatch();// 将参数加入到批处理
					connection.commit();// 提交
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					if (pstmt != null) {
						try {
							pstmt.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}
				}
				try {
					if (connection != null && (!connection.isClosed())) {
						connection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		});
		if (session.isOpen()) {
			session.close();
		}
	}

	@Override
	public void batchUpdateSQL(final String sql, final Object[] values) {
		Session session = this.getSessionFactory().openSession();

		session.doWork(new Work() {
			public void execute(Connection connection) throws SQLException {
				PreparedStatement pstmt = null;
				try {
					connection.setAutoCommit(false);// 手动提交
					pstmt = connection.prepareStatement(sql);// 预编译
					for (int i = 0; i < values.length; i++) {
						pstmt.setObject(1, values[i]);
						pstmt.addBatch();
					}
					pstmt.executeBatch();// 将参数加入到批处理
					connection.commit();// 提交
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					if (pstmt != null) {
						try {
							pstmt.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}
				}
				try {
					if (connection != null && (!connection.isClosed())) {
						connection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		});
		if (session.isOpen()) {
			session.close();
		}
	}

	@Override
	public void execute(HibernateCallback hibernateCallback) {
		getHibernateTemplate().execute(hibernateCallback);
	}

	@Override
	public Session getCurrentSession() {
		return super.getHibernateTemplate().getSessionFactory()
				.getCurrentSession();
	}

	@Override
	public void initialize(Object proxy) {
		if (!Hibernate.isInitialized(proxy)) {
			Hibernate.initialize(proxy);
		}
	}

	@Override
	public void initializeDeep(Collection collection) {

		if (collection == null) {
			return;
		}

		for (Object obj : collection) {
			Method[] methods = obj.getClass().getMethods();
			if (methods != null) {
				for (int j = 0; j < methods.length; j++) {
					String getName = methods[j].getName();
					if (getName.length() > 3 && getName.startsWith("get")) {
						String getFix = getName.substring(3, getName.length());
						for (int k = 0; k < methods.length; k++) {
							String setName = methods[k].getName();
							if (setName.length() > 3
									&& setName.startsWith("set")) {
								String setFix = setName.substring(3,
										setName.length());
								if (getFix.equals(setFix)) {
									try {
										Object o = methods[j].invoke(obj,
												new Object[0]);
										if (o != null) {
											Hibernate.initialize(o);
											methods[k].invoke(obj, o);
										}

									} catch (IllegalArgumentException e) {
										e.printStackTrace();
									} catch (IllegalAccessException e) {
										e.printStackTrace();
									} catch (InvocationTargetException e) {
										e.printStackTrace();
									}
								}
							}
						}
					}

				}
			}

		}
	}

	@Override
	public void evictQuery() {
		if (null != DEFAULTQUERYCACHEREGION
				|| (!"".equals(DEFAULTQUERYCACHEREGION))) {
			getHibernateTemplate().getSessionFactory().getCache()
					.evictQueryRegion(DEFAULTQUERYCACHEREGION);
		} else {
			getHibernateTemplate().getSessionFactory().getCache()
					.evictQueryRegions();
		}
	}

	@Override
	public void evictQuery(String queryCacheRegion) {
		getHibernateTemplate().getSessionFactory().getCache()
				.evictQueryRegion(queryCacheRegion);
	}

	@Override
	public void evictEntity(Class c) {
		// 3.X：HibernateSessionFactory.getSessionFactory().evict(Qx.class);
		this.getSessionFactory().getCache().evictEntityRegion(c);
	}

	@Override
	public void evictEntity(Class c, Serializable id) {
		// HibernateSessionFactory.getSessionFactory().evict(Qx.class,new
		// Integer(102));
		this.getSessionFactory().getCache().evictEntity(c, id);
	}

	@Override
	public void evictCollectionRegion(String collectionRegion) {
		// HibernateSessionFactory.getSessionFactory().evictCollection("entity.Qx.jds");
		this.getSessionFactory().getCache()
				.evictCollectionRegion(collectionRegion);
	}

	@Override
	public void evictCollectionRegion(String collectionRegion, Serializable id) {
		// HibernateSessionFactory.getSessionFactory().evictCollection(" entity.Qx.jds ",new
		// Integer(102));
		this.getSessionFactory().getCache()
				.evictCollection(collectionRegion, id);

	}

	@Override
	public int findMaxPage(String hql, int rowsPerPage, Object... values) {
		return (this.findCount(hql, values) - 1) / rowsPerPage + 1;
	}
	@Override
	public int findMaxPage(String hql, int rowsPerPage, EasyCriteria easyCriteria) {
		return (this.findCount(hql, easyCriteria) - 1) / rowsPerPage + 1;
	}

	@Override
	public <T> T findVal(String hql, Object... values) {
		List list = this.find(hql, values);
		return (T) (list.size() > 0 ? list.get(0) : null);
	}
	@Override
	public <T> T findVal(String hql,  EasyCriteria easyCriteria) {
		List list = this.find(hql, easyCriteria);
		return (T) (list.size() > 0 ? list.get(0) : null);
	}



	

}
