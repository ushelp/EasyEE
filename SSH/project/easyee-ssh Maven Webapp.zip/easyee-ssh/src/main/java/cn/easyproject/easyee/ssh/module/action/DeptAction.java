package cn.easyproject.easyee.ssh.module.action;

import cn.easyproject.easyee.ssh.module.criteria.DeptCriteria;
import cn.easyproject.easyee.ssh.module.entity.Dept;
import cn.easyproject.easyee.ssh.module.service.DeptService;
import cn.easyproject.easyee.ssh.base.action.BaseAction;
import cn.easyproject.easyee.ssh.base.util.PageBean;
import cn.easyproject.easyee.ssh.base.util.StatusCode;
/**
 * 所有Action处理类统一继承BaseAction
 * 
 * BaseAction中定义了一下内容：
 * - request, application Servlet API
 * - 请求响应相关的JSON参数（EasyUI框架请求都是通过JSON响应）
 * - 初始化JSON响应数据的方法（setJsonMap，setJsonMsgMap，setJsonPaginationMap(PageBean, Object...)）
 * - EasyUI分页信息相关的属性
 * - result="json" 的 JSON 常量
 * 
 * 
 * @author easyproject.cn
 * @version 1.0
 *
 */
public class DeptAction extends BaseAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	// 必须和@Service("deptService")注解声明的业务Bean名称相同
	// 必须有setter方法
	private DeptService deptService;
	
	private Dept dept;
	private DeptCriteria deptCriteria;
	
	
	/**
	 * CRUD
	 * @return
	 */
	public String save(){
		// 保存用户
		try {
			deptService.add(dept);
			
			// 处理成功 消息
			msg = getText("msg.saveSuccess");

			// 如果需要刷新，跳转到最后一页
//			super.page = deptService.findMaxPage(rows);
		} catch (Exception e) {
			e.printStackTrace();
			msg = getText("msg.saveFail");
			statusCode=StatusCode.ERROR; //默认为OK
		}
		
		/*
		 * Ajax响应信息
		 * statusCode：响应状态码;  
		 * msg: 响应消息;   
		 * callback: 执行回调函数,
		 * locationUrl: 跳转页面
		 */
		// EasyUI框架响应结果都是JSON
		// JSON数据初始化，包含EasySSH Ajax响应信息
//		super.setJsonMsgMap();
		// 添加数据后，使用rowData信息更新行的内容
		super.setJsonMsgMap("rowData", dept);
		
		// 返回JSON
		return JSON;
	}
	
	/**
	 * 分页
	 * @return
	 */
	public String list(){
		PageBean pb = super.getPageBean(); // 获得分页对
		deptService.findByPage(pb,deptCriteria);
		// EasyUI框架响应结果都是JSON
		// JSON数据初始化，包含EasySSH Ajax响应信息和分页信息
		super.setJsonPaginationMap(pb);
		return JSON;
	}

	
	public String delete(){
		try {
			deptService.delete(dept.getDeptno());
		} catch (Exception e) {
			e.printStackTrace();
			statusCode=StatusCode.ERROR;
		}
		super.setJsonMsgMap();
		return JSON;
	}
	
	public String update(){
		try {
			deptService.update(dept);
			msg=getText("msg.updateSuccess");
		} catch (Exception e) {
			e.printStackTrace();
			msg=getText("msg.updateFail");
			statusCode=StatusCode.ERROR;
		}
		setJsonMsgMap();
		return JSON;
	}

	public Dept getDept() {
		return dept;
	}

	public void setDept(Dept dept) {
		this.dept = dept;
	}

	public void setDeptService(DeptService deptService) {
		this.deptService = deptService;
	}

	public DeptCriteria getDeptCriteria() {
		return deptCriteria;
	}

	public void setDeptCriteria(DeptCriteria deptCriteria) {
		this.deptCriteria = deptCriteria;
	}
	
	
	
}
