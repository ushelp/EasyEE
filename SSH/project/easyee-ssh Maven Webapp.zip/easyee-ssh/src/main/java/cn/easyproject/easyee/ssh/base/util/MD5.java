package cn.easyproject.easyee.ssh.base.util;

import org.acegisecurity.providers.encoding.MessageDigestPasswordEncoder;

/**
 * MD5加密工具类
 * @author easyproject.cn
 *
 */
public class MD5 {

	private static MessageDigestPasswordEncoder mdpe = new MessageDigestPasswordEncoder(
			"MD5");
	
	private static final String SALT = "salt"; //加密盐

	/**
	 *  使用默认SALT加密原始字符串
	 * @param saw 原始字符串
	 * @return 加密后的字符串
	 */
	public static String getMd5(String saw) {
		return mdpe.encodePassword(saw, SALT);
	}
	/**
	 * 使用指定SALT加密原始字符串
	 * @param saw 原始字符串
	 * @param salt 加密盐
	 * @return 加密后的字符串
	 */
	public static String getMd5(String saw,String salt) {
		return mdpe.encodePassword(saw, salt);
	}

	public static void main(String[] args) {
		System.out.println(MD5.getMd5("lisa"));
	}
}
