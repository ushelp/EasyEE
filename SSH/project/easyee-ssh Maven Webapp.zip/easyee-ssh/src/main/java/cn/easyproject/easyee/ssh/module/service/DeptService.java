package cn.easyproject.easyee.ssh.module.service;

import java.util.List;

import cn.easyproject.easyee.ssh.module.criteria.DeptCriteria;
import cn.easyproject.easyee.ssh.module.entity.Dept;
import cn.easyproject.easyee.ssh.base.util.PageBean;
/**
 * 
 * @author easyproject.cn
 * @version 1.0
 *
 */
public interface DeptService {
	public void add(Dept dept);

	public void delete(Integer deptno);

	public void update(Dept dept);

	public Dept get(Integer deptno);

	public void findByPage(PageBean pageBean, DeptCriteria deptCriteria);

	public int findMaxPage(int rowPerPage);
	
	public List<Dept> findAll();
}
