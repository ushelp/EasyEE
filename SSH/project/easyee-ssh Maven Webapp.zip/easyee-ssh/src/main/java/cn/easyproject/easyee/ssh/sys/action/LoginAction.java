package cn.easyproject.easyee.ssh.sys.action;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.easyproject.easyee.ssh.sys.entity.SysUser;
import cn.easyproject.easyee.ssh.sys.service.SysOperationPermissionService;
import cn.easyproject.easyee.ssh.sys.service.SysUserService;
import cn.easyproject.easyee.ssh.base.action.BaseAction;
import cn.easyproject.easyee.ssh.base.util.StatusCode;

/**
 * 
 * @author easyproject.cn
 * @version 1.0
 *
 */
public class LoginAction extends BaseAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static Logger logger=LoggerFactory.getLogger(LoginAction.class);
	
	private SysUser sysUser;
	private SysUserService sysUserService;
	private SysOperationPermissionService sysOperationPermissionService;
	private String verifyCode;

	/**
	 * 执行登录
	 */
	public String execute() {
		HttpSession session = request.getSession();
		if (session.getAttribute("rand") != null
				&& session.getAttribute("rand").toString()
						.equalsIgnoreCase(verifyCode)) {
			session.removeAttribute("rand");

			sysUser = sysUserService.login(sysUser);

			if (sysUser != null) {
				if (sysUser.getStatus() == SysUser.STATUS_LOCK) {
					session.setAttribute("MSG",
							getText("sys.LoginAction.lockError"));
				} else {
					// TODO 存储用户信息、菜单、权限
					session.setAttribute("USER", sysUser); // 用户信息存储
					super.setPermissions(); // 用户菜单权限、操作权限生成和存储
					// 保存所有权限对应的权限名称，权限备注
					session.setAttribute("operationsName", sysOperationPermissionService.getAllOpreationNames());
					return SUCCESS;
				}
			} else {
				session.setAttribute("MSG",
						getText("sys.LoginAction.loginError"));
			}
		} else {
			session.removeAttribute("rand");
			session.setAttribute("MSG", getText("sys.LoginAction.verifyCodeError"));
		}

		return LOGIN_REDIRECT;
	}

	/**
	 * 用户自动重新登录，测试权限分配用
	 */
	public String reLogin() {
		HttpSession session = request.getSession();
		sysUser = sysUserService.login(getLoginUser());
		session.setAttribute("USER", sysUser); // SysUser info
		// 保存所有权限对应的权限名称，权限备注
		session.setAttribute("operationsName", sysOperationPermissionService.getAllOpreationNames());
		super.setPermissions();
		return SUCCESS;
	}

	/**
	 * 验证码检测
	 * 
	 * @return
	 */
	public String checkVerifyCode() {
		HttpSession session = request.getSession();
		if (!(session.getAttribute("rand") != null && session
				.getAttribute("rand").toString().equalsIgnoreCase(verifyCode))) {
			statusCode=StatusCode.ERROR;
			msg=getText("sys.LoginAction.verifyCodeError");
		}

		super.setJsonMsgMap();
		return JSON;
	}
	
	
	/**
	 * 注销
	 */
	public String logout() throws Exception {
		request.getSession().invalidate();
		request.getSession(); //new Session
		return LOGIN_REDIRECT;
	}

	public SysUser getSysUser() {
		return sysUser;
	}

	public void setSysUser(SysUser sysUser) {
		this.sysUser = sysUser;
	}

	public void setSysUserService(SysUserService sysUserService) {
		this.sysUserService = sysUserService;
	}

	public void setVerifyCode(String verifyCode) {
		this.verifyCode = verifyCode;
	}

	public void setSysOperationPermissionService(
			SysOperationPermissionService sysOperationPermissionService) {
		this.sysOperationPermissionService = sysOperationPermissionService;
	}

}
