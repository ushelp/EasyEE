package cn.easyproject.easyee.ssh.sys.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.management.relation.RoleList;
import javax.servlet.ServletResponse;

import org.apache.struts2.ServletActionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.easyproject.easyee.ssh.sys.entity.SysOperationPermission;
import cn.easyproject.easyee.ssh.sys.entity.SysRole;
import cn.easyproject.easyee.ssh.sys.service.SysOperationPermissionService;
import cn.easyproject.easyee.ssh.sys.service.SysRoleService;
import cn.easyproject.easyee.ssh.base.action.BaseAction;
import cn.easyproject.easyee.ssh.base.util.PageBean;
import cn.easyproject.easyee.ssh.base.util.StatusCode;
import cn.easyproject.easyee.ssh.base.util.StringUtils;

/**
 * 
 * @author easyproject.cn
 * @version 1.0
 * 
 */
@SuppressWarnings({ "rawtypes", "unused" })
public class SysOperationPermissionAction extends BaseAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static Logger logger=LoggerFactory.getLogger(SysOperationPermissionAction.class);
	
	private SysOperationPermission sysOperationPermission;
	private SysOperationPermissionService sysOperationPermissionService;
	private String menuId;

	@Override
	public String execute() throws Exception {
		return SUCCESS;
	}
	
	
	public String list(){
		jsonRoot=new Object[]{};
		if(isNotNullAndEmpty(menuId)){
			List list=sysOperationPermissionService.list(Integer.valueOf(menuId));
			jsonRoot=list;
			setJsonMap("rows",list,"sysMenuPermission.menuPermissionId",menuId);
		}
		return JSON;
	}
	
	public String update(){
		try {
			sysOperationPermissionService.update(sysOperationPermission);
			msg=getText("msg.updateSuccess");
			super.refreshPermissions(); //刷新权限
		} catch (Exception e) {
			logger.error(getText("sys.OperationPermissionAction.updateException"),e);
			e.printStackTrace();
			msg=getText("msg.updateFail");
			statusCode=StatusCode.ERROR;
		}
		setJsonMsgMap();
		return JSON;
	}
	public String save(){
		try {
			sysOperationPermissionService.add(sysOperationPermission);
			msg=getText("msg.saveSuccess");
			super.refreshPermissions(); //刷新权限
		} catch (Exception e) {
			logger.error(getText("sys.OperationPermissionAction.saveException"),e);
			e.printStackTrace();
			msg=getText("msg.saveFail");
			statusCode=StatusCode.ERROR;
		}
		System.out.println(sysOperationPermission.getOperationPermissionId());
		setJsonMsgMap("operationPermissionId",sysOperationPermission.getOperationPermissionId());
		return JSON;
	}
	public String delete(){
		try {
			sysOperationPermissionService.delete(sysOperationPermissionService.get(sysOperationPermission.getOperationPermissionId()));;
			msg=getText("msg.deleteSuccess");
			super.refreshPermissions(); //刷新权限
		} catch (Exception e) {
			logger.error(getText("sys.OperationPermissionAction.deleteException"),e);
			e.printStackTrace();
			msg=getText("msg.deleteSuccess");
			statusCode=StatusCode.ERROR;
		}
		setJsonMsgMap();
		return JSON;
	}


	public void setSysOperationPermission(SysOperationPermission sysOperationPermission) {
		this.sysOperationPermission = sysOperationPermission;
	}


	public SysOperationPermission getSysOperationPermission() {
		return sysOperationPermission;
	}


	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}


	public void setSysOperationPermissionService(
			SysOperationPermissionService sysOperationPermissionService) {
		this.sysOperationPermissionService = sysOperationPermissionService;
	}

	
}
