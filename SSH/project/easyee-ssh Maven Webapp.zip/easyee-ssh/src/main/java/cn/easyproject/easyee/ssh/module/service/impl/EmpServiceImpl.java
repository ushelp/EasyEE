package cn.easyproject.easyee.ssh.module.service.impl;


import org.springframework.stereotype.Service;

import cn.easyproject.easyee.ssh.module.criteria.EmpCriteria;
import cn.easyproject.easyee.ssh.module.entity.Emp;
import cn.easyproject.easyee.ssh.module.service.EmpService;
import cn.easyproject.easyee.ssh.base.service.BaseService;
import cn.easyproject.easyee.ssh.base.util.PageBean;

/**
 * 业务实现类统一继承BaseService类
 * BaseService中注入了通用DAO，直接调用commonDAO的数据方法方法即可
 * 
 * @author easyproject.cn
 * @version 1.0
 *
 * 
 */
@Service("empService")
public class EmpServiceImpl extends BaseService implements EmpService {

	@Override
	public void add(Emp emp) {
		commonDAO.save(emp);
	}

	@Override
	public void delete(Integer empno) {
		commonDAO.updateByHql("delete from Emp where empno=?",empno);
	}

	@Override
	public void update(Emp emp) {
		commonDAO.update(emp);
	}

	@Override
	public Emp get(Integer empno) {
		return commonDAO.get(Emp.class, empno);
	}

	@Override
	public void findByPage(PageBean pageBean, EmpCriteria empCriteria) {
		pageBean.setEntityName("Emp emp");
		pageBean.setSelect("select emp");
		
		// 按条件分页
		commonDAO.findByPage(pageBean,empCriteria);
	}

	@Override
	public int findMaxPage(int rowPerPage) {
		return (commonDAO.findMaxPage("select count(*) from Emp", rowPerPage)-1)/rowPerPage+1;
	}

	@Override
	public void delete(String[] empnos) {
		StringBuilder sb=new StringBuilder();
		sb.append("");
		for (String id : empnos) {
			sb.append(id+",");
		}
		sb.deleteCharAt(sb.length()-1).append("");
		
		commonDAO.deleteByValues(Emp.class, "empno", sb.toString());
		
	}

}
