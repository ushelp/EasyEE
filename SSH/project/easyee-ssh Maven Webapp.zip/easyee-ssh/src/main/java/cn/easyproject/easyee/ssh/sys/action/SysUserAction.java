package cn.easyproject.easyee.ssh.sys.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.management.relation.RoleList;
import javax.servlet.ServletResponse;

import org.apache.struts2.ServletActionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.easyproject.easycommons.objectutils.EasyObjectExtract;
import cn.easyproject.easyee.ssh.sys.criteria.SysUserCriteria;
import cn.easyproject.easyee.ssh.sys.entity.SysRole;
import cn.easyproject.easyee.ssh.sys.entity.SysUser;
import cn.easyproject.easyee.ssh.sys.service.SysRoleService;
import cn.easyproject.easyee.ssh.sys.service.SysUserService;
import cn.easyproject.easyee.ssh.base.action.BaseAction;
import cn.easyproject.easyee.ssh.base.util.PageBean;
import cn.easyproject.easyee.ssh.base.util.StatusCode;
import cn.easyproject.easyee.ssh.base.util.StringUtils;

/**
 * 
 * @author easyproject.cn
 * @version 1.0
 * 
 */
@SuppressWarnings({ "rawtypes", "unused" })
public class SysUserAction extends BaseAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static Logger logger=LoggerFactory.getLogger(SysUserAction.class);
	
	private SysUser sysUser;
	private SysUserCriteria sysUserCriteria;
	private SysUserService sysUserService;
	/* private SysRoleService sysRoleService; */

	private String newPwd;
	private String confirmPwd;
	private String[] roleIds = {};
	// 要删除的用户ID列表，#分隔
//	private String userId;
	private String[] userId ;//多行批量删除

	/* private List<RoleList> roles=new ArrayList<RoleList>(); */

	@Override
	public String execute() throws Exception {
		return SUCCESS;
	}

	/**
	 * 分页查询
	 * 
	 * @return
	 * @throws Exception
	 */
	public String list() throws Exception {
		PageBean pb = super.getPageBean(); // 获得分页对象

		sysUserService.findByPage(pb, sysUserCriteria);

		// 使用EasyObjectUtils指定fieldExpression将无需序列化和使用的属性设为null，防止JSON序列化引起延迟加载异常
		// EasyObjectSetNull.setNull(pb.getData(),
		// "{sysRoles}.sysOperationPermissions", "{sysRoles}.sysUsers");

		// 从分页集合中抽取需要输出的分页数据，不需要的不用输出，而且可以防止no session异常

		List<Map> list = EasyObjectExtract.extract(pb.getData(), "userId","realName",
				"name", "status", "{sysRoles}.name#roleNames",
				"{sysRoles}.roleId#roleIds");
		// 使用抽取的集合作为分页数据
		pb.setData(list);

		super.setJsonPaginationMap(pb);
		return JSON;
	}

	/*
	 * public String toEdit(){ roles=sysRoleService.list(); return "toEdit"; }
	 */

	public String changePwd() {
		SysUser u = (SysUser) request.getSession().getAttribute("USER");
		msg = getText("sys.UserAction.pwdFail");
	
		if (u != null && u.getPassword().equals(sysUser.getPassword())) {
			if (u.getPassword().equals(newPwd)) {
				try {
					sysUserService.changePwd(u.getUserId(), newPwd);
					msg = getText("msg.updateSuccess");
				} catch (Exception e) {
					statusCode=StatusCode.ERROR;
					logger.error(getText("sys.UserAction.pwdException"), e);
				}
			}
		} else {
			statusCode=StatusCode.ERROR;
			msg = getText("sys.UserAction.pwdWrongError");
		}
		super.setJsonMsgMap();
		return JSON;
	}

	/**
	 * 添加用户
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public String save() {
		statusCode=StatusCode.ERROR;
		msg = getText("msg.saveFail");
		if (sysUser.getPassword() != null
				&& sysUser.getPassword().equals(confirmPwd)) {

			if (sysUserService.existsName(sysUser.getName())) {
				msg = getText("sys.UserAction.userExists");
			} else {
				for (String roleId : roleIds) { // 保存角色
					sysUser.getSysRoles().add(
							new SysRole(Integer.valueOf(roleId)));
				}
				// 保存用户
				try {
					sysUserService.add(sysUser);
					msg = getText("msg.saveSuccess");
					statusCode=StatusCode.OK;
					msg="";
					// 跳转到最后一页
					super.page = sysUserService.findMaxPage(rows);
				} catch (Exception e) {
					logger.error(getText("sys.UserAction.saveException"), e);
				}
			}

		} else {
			msg = getText("sys.UserAction.pwdNotEqauals");
		}
		super.setJsonMsgMap("page", super.page);
		return JSON;
	}

	/**
	 * 删除用户
	 * 
	 * @return
	 */
	public String delete() {
		try {
			sysUserService.delete(userId);
//			sysUserService.delete(sysUser.getUserId());
		} catch (Exception e) {
			e.printStackTrace();
			// 出错输出 500 响应
			// ServletActionContext.getResponse().setStatus(500);
			statusCode=StatusCode.ERROR;
		}
		super.setJsonMsgMap();
		return JSON;
	}

	/**
	 * 修改用户
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public String update() {
		msg = getText("msg.updateFail");
		statusCode=StatusCode.ERROR;
		if (sysUser.getPassword() != null
				&& sysUser.getPassword().equals(confirmPwd)) {
			try {
				if (sysUserService.existsName(sysUser.getName(),sysUser.getUserId())) {
					msg = getText("sys.UserAction.userExists");
				} else {
					String oldPwd = sysUserService.getPwd(sysUser.getUserId());
					sysUser.getSysRoles().clear(); // 清除原角色
					for (String roleId : roleIds) { // 保存角色
						sysUser.getSysRoles().add(
								new SysRole(Integer.valueOf(roleId)));
					}
					// 判断密码是否修改了，没有修改则使用旧密码
					if (!isNotNullAndEmpty(sysUser.getPassword())) {
						sysUser.setPassword(oldPwd);
					}
					// 保存用户
					sysUserService.update(sysUser);
					msg = getText("msg.updateSuccess");
					statusCode=StatusCode.OK;
					
					// 如果修改的是当前用户自己，则刷新其菜单权限和操作权限
					if(sysUser.getUserId()==getLoginUser().getUserId()){
						refreshPermissions(); //自动刷新菜单权限
						// TODO 刷新操作权限
					}
					// 修改刷新当前页
					// super.page=sysUserService.findMaxPage(rows);
				}
			} catch (Exception e) {
				logger.error(getText("sys.UserAction.updateException"), e);
			}

		} else {
			msg = getText("sys.UserAction.pwdNotEqauals");
		}
		super.setJsonMsgMap();
		return JSON;
	}

	public SysUser getSysUser() {
		return sysUser;
	}

	public void setSysUser(SysUser sysUser) {
		this.sysUser = sysUser;
	}

	public SysUserService getSysUserService() {
		return sysUserService;
	}

	public void setSysUserService(SysUserService sysUserService) {
		this.sysUserService = sysUserService;
	}

	public void setNewPwd(String newPwd) {
		this.newPwd = newPwd;
	}

	public void setConfirmPwd(String confirmPwd) {
		this.confirmPwd = confirmPwd;
	}

	public void setRoleIds(String[] roleIds) {
		this.roleIds = roleIds;
	}

	public void setUserId(String[] userId) {
		this.userId = userId;
	}
//	public void setUserId(String userId) {
//		this.userId = userId;
//	}

	public SysUserCriteria getSysUserCriteria() {
		return sysUserCriteria;
	}

	public void setSysUserCriteria(SysUserCriteria sysUserCriteria) {
		this.sysUserCriteria = sysUserCriteria;
	}

	/*
	 * public void setSysRoleService(SysRoleService sysRoleService) {
	 * this.sysRoleService = sysRoleService; }
	 * 
	 * public List<RoleList> getRoles() { return roles; }
	 */

}
