package cn.easyproject.easyee.ssh.sys.service.impl;

import java.util.List;

import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Service;

import cn.easyproject.easyee.ssh.sys.criteria.SysRoleCriteria;
import cn.easyproject.easyee.ssh.sys.entity.SysRole;
import cn.easyproject.easyee.ssh.sys.service.SysRoleService;
import cn.easyproject.easyee.ssh.base.service.BaseService;
import cn.easyproject.easyee.ssh.base.util.PageBean;

/**
 * 
 * @author easyproject.cn
 * @version 1.0
 * 
 */
@Service("sysRoleService")
@SuppressWarnings("rawtypes")
public class SysRoleServiceImpl extends BaseService implements SysRoleService {

	@Override
	public void add(SysRole SysRole) {
		commonDAO.save(SysRole);
	}

	@Override
	public void delete(int id) {
			commonDAO.delete(SysRole.class, id);
	}

	@Override
	public void update(SysRole SysRole) {
			commonDAO.update(SysRole);
	}

	@Override
	public SysRole get(int id) {
		return commonDAO.get(SysRole.class, id);
	}

	@Override
	public List list() {
		return commonDAO.findByCache("from SysRole", "SysRole.list");
	}

	@Override
	public void findByPage(PageBean pb, SysRoleCriteria sysRoleCriteria) {
		pb.setEntityName("SysRole s");
		pb.setSelect("select s");
		
		// 按条件分页查询
		commonDAO.findByPage(pb,sysRoleCriteria);
	}

	@Override
	public int findMaxPage(int rowsPerPage) {
		return (commonDAO.findMaxPage("select count(*) from SysRole", rowsPerPage)-1)/rowsPerPage+1;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List getAllPermissionsIds(int roleId) {
		//查询角色的菜单权限Id和操作权限Id
		List menuIds=commonDAO.findBySQL("select 'menu' as type,menu_Permission_Id as id from sys_role_menu_permission where ROLE_ID=?",Transformers.ALIAS_TO_ENTITY_MAP,roleId);
		List permissionIds=commonDAO.findBySQL("select 'operation' as type,Operation_Permission_Id as id from sys_role_operation_permission where ROLE_ID=?",Transformers.ALIAS_TO_ENTITY_MAP,roleId);
		//返回所有权限id
		menuIds.addAll(permissionIds);
		return menuIds;
	}
	@Override
	public boolean existsName(String name) {
			return commonDAO.findCount("select count(*) from SysRole where lower(name)=?", name.toLowerCase())>0;
	}
	@Override
	public boolean existsName(String name, Integer roleId) {
		//修改用户时，检测用户名是否存在
			return commonDAO.findCount("select count(*) from SysRole where lower(name)=? and roleId!=?", name.toLowerCase(), roleId)>0;
	}

}
