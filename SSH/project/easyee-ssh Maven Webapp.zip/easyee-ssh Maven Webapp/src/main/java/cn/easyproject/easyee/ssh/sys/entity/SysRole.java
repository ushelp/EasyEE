package cn.easyproject.easyee.ssh.sys.entity;

import java.util.HashSet;
import java.util.Set;

import org.apache.struts2.json.annotations.JSON;

/**
 * SysRole entity. 
 * @author easyproject.cn
 * @version 1.0
 */
@SuppressWarnings("rawtypes")
public class SysRole implements java.io.Serializable {

	// Fields
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer roleId;
	private String name;
	private Integer status;
	private String remark;
	private Set sysOperationPermissions = new HashSet(0);
	private Set sysMenuPermissions = new HashSet(0);
	private Set sysUsers = new HashSet(0);

	// Constructors

	/** default constructor */
	public SysRole() {
	}

	public SysRole(Integer roleId) {
		super();
		this.roleId = roleId;
	}

	/** minimal constructor */
	public SysRole(String name) {
		this.name = name;
	}

	/** full constructor */
	public SysRole(String name, Integer status, String remark,
			Set sysOperationPermissions, Set sysMenuPermissions, Set sysUsers) {
		this.name = name;
		this.status = status;
		this.remark = remark;
		this.sysOperationPermissions = sysOperationPermissions;
		this.sysMenuPermissions = sysMenuPermissions;
		this.sysUsers = sysUsers;
	}

	// Property accessors

	public Integer getRoleId() {
		return this.roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
	@JSON(serialize=false)
	public Set getSysOperationPermissions() {
		return this.sysOperationPermissions;
	}
	
	public void setSysOperationPermissions(Set sysOperationPermissions) {
		this.sysOperationPermissions = sysOperationPermissions;
	}
	@JSON(serialize=false)
	public Set getSysMenuPermissions() {
		return this.sysMenuPermissions;
	}

	public void setSysMenuPermissions(Set sysMenuPermissions) {
		this.sysMenuPermissions = sysMenuPermissions;
	}
	@JSON(serialize=false)
	public Set getSysUsers() {
		return this.sysUsers;
	}

	public void setSysUsers(Set sysUsers) {
		this.sysUsers = sysUsers;
	}

	@Override
	public String toString() {
		return "SysRole [roleId=" + roleId + ", name=" + name + ", status="
				+ status + ", remark=" + remark + "]";
	}

}