package cn.easyproject.easyee.ssh.sys.interceptor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.easyproject.easyee.ssh.base.util.StatusCode;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;

/**
 * 用户权限检测过滤拦截器
 * @author easyproject.cn
 * @version 1.0
 *
 */
public class UserInterctptor extends MethodFilterInterceptor {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static Logger logger = LoggerFactory
			.getLogger(UserInterctptor.class);

	/**
	 * 接收排除的类名ClassNames，支持正则表达式
	 */
	private String excludeClassNames;
	/**
	 * 接收排除的ActionName，支持正则表达式
	 */
	private String excludeActionNames;

	/**
	 * 排除的ClassName数组
	 */
	private List<Pattern> classNamesPattern = new ArrayList<Pattern>();
	/**
	 * 排除的ActionName数组
	 */
	private List<Pattern> actionNamesPattern = new ArrayList<Pattern>();
	
	@Override
	/**
	 * 初始化拦截器需要的参数信息
	 */
	public void init() {
		/*
		 *排除正则初始化
		 */
		String[] classNames = excludeClassNames.split(",");
		String[] actionNames = excludeActionNames.split(",");

		Pattern p = null;
		for (String className : classNames) {
			p = Pattern.compile(className);// 转换为正则表达式
			classNamesPattern.add(p);
		}
		for (String actionName : actionNames) {
			p = Pattern.compile(actionName);// 转换为正则表达式
			actionNamesPattern.add(p);
		}
		
		logger.debug(classNamesPattern.toString());
		logger.debug(actionNamesPattern.toString());


	}
	public static void main(String[] args) {
		// TODO 移除测试main方法
		Pattern p=Pattern.compile("cn\\.easyproject\\.easyssh\\.sys\\.action\\.LoginAction");
		System.out.println(p.matcher("cn.easyproject.easyee.ssh.sys.action.LoginAction").matches());
	}
	@SuppressWarnings("unchecked")
	@Override
	protected String doIntercept(ActionInvocation actionInvocation)
			throws Exception {
		
		// 判断是否是权限验证排除的类、actionName或方法
		String className=actionInvocation.getAction().getClass().getName();
		String actionname=actionInvocation.getProxy().getActionName();
		
		// 是否排除验证
		boolean excludeClass=false;
		boolean excludeAction=false;
		
		
		for(Pattern p:classNamesPattern){
			System.out.println(p);
			System.out.println(p.matcher(className).matches());
			if(p.matcher(className).matches()){
				excludeClass=true;
				break;
			}
		}
		if(!excludeClass){
			for(Pattern p:actionNamesPattern){
				if(p.matcher(actionname).matches()){
					excludeAction=true;
					break;
				}
			}
		}
		if(excludeClass || excludeAction){
			logger.debug("排除验证："+excludeClass+", "+excludeAction);
			return actionInvocation.invoke();
		}
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = ServletActionContext.getRequest().getSession();
		
		String msg="您的登录已过期，请重新登录！";
		int statusCode=StatusCode.TIMEOUT;
		String locationUrl="toLogin.action";
		
		if(session.getAttribute("USER")!=null){
			//如果用户已登录判断权限
			// 用户允许的操作权限
			Set<String> operations = (Set<String>) session
					.getAttribute("operations");
			String action = null;
			if (operations != null) {
				// String action=actionInvocation.getProxy().getActionName();
				// logger.debug("欲操作权限为："+action+actionInvocation.getProxy().get);
				// logger.debug("您的操作权限为："+operations);

				String path = request.getContextPath();

				if (path.length() > 1) {
					action = request.getRequestURI().substring(path.length() + 1);
				} else {
					action = request.getRequestURI().substring(path.length());
				}
				logger.debug("URI为：" + request.getRequestURI());
				logger.debug("欲操作权限为：" + action);
				logger.debug("您的操作权限为：" + operations);
				logger.debug("验证结果：" + operations.contains(action));
				// 权限验证通过
				if (operations.contains(action)) {
					return actionInvocation.invoke();
				}else{
					Map<String,String> operationsName=(Map<String, String>) session.getAttribute("operationsName");
					if( operationsName.get(action)!=null){
						msg="您没有[" + operationsName.get(action) + "]的操作权限!";
					}else{
						msg="您没有[" +action + "]的操作权限!";
					}
					statusCode=StatusCode.NO_PERMISSSION;
					locationUrl="";
				}
			}
		}
		
	
		/*
		 *  验证未通过统一处理
		 */
		if (request != null
				&& ("XMLHttpRequest".equalsIgnoreCase(request
						.getHeader("X-Requested-With")) || "XMLHttpRequest".equalsIgnoreCase(request.getParameter("xRequestedWith")))) {
			//AJax请求处理
			// 没有权限，返回错误信息
			Map<String, String> jsonRoot = new HashMap<String, String>();
			jsonRoot.put("msg", msg); //消息
			jsonRoot.put("statusCode", statusCode+""); // 状态码
			jsonRoot.put("locationUrl", locationUrl); // 重定向到的浏览器地址，主要是重新登录用
			
			//其他防止EasyUI找不到数据，出现代码异常的其他空参数
			jsonRoot.put("rows", "");
			jsonRoot.put("list", "");
			//未登录，跳转到登录页面
			// jsonRoot信息
			actionInvocation.getInvocationContext().getValueStack()
					.set("jsonRoot", jsonRoot);
			return "json";
			
		}else{
			// 非Ajax请求直接跳转到登录页面
			return "loginRedirect";
		}
		
	}

	public String getExcludeClassNames() {
		return excludeClassNames;
	}

	public void setExcludeClassNames(String excludeClassNames) {
		this.excludeClassNames = excludeClassNames;
	}

	public String getExcludeActionNames() {
		return excludeActionNames;
	}

	public void setExcludeActionNames(String excludeActionNames) {
		this.excludeActionNames = excludeActionNames;
	}

}
