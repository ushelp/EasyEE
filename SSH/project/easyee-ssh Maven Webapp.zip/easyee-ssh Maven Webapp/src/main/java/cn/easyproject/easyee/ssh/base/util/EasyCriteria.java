package cn.easyproject.easyee.ssh.base.util;

import java.util.ArrayList;
import java.util.List;

/**
 * 按条件查询抽象父类（可以结合分页PageBean使用）
 * @author easyproject.cn
 * @version 1.0
 * 
 * SysUser查询标准条件类使用Demo: <br/>

 <pre>
 public class SysUserCriteria extends EasyCriteria implements java.io.Serializable {
 	// 1. 添加条件属性
 	private String name;
 	private String realName;
 	private Integer status; // 用户状态：0启用；1禁用；2删除
 
 	// 2. 生成构造方法
 	public SysUserCriteria() {
 	}
 
 	public SysUserCriteria(String name, String realName, Integer status) {
 		super();
 		this.name = name;
 		this.realName = realName;
 		this.status = status;
 	}
 
 	// 3. 条件生成抽象方法实现
 	public String getCondition() {
 		values.clear(); //清除条件数据
 		StringBuffer condition = new StringBuffer();
 		if (StringUtils.isNotNullAndEmpty(this.getName())) {
 			condition.append(" and name like ?");
 			values.add("%" + this.getName() + "%");
 		}
 		if (StringUtils.isNotNullAndEmpty(this.getRealName())) {
 			condition.append(" and realName like ?");
 			values.add("%" + this.getRealName() + "%");
 		}
 		if (StringUtils.isNotNullAndEmpty(this.getStatus())) {
 			condition.append(" and status=?");
 			values.add(this.getStatus());
 		}
 		return condition.toString();
 	}
 
 	// 4. Setters&Getters...
 
 }
 </pre>
 */
public abstract class EasyCriteria {
	protected List<Object> values = new ArrayList<Object>();
	
	public abstract String getCondition() ;
	
	
	public List<Object> getValues() {
		return values;
	}
	public void setValues(List<Object> values) {
		this.values = values;
	}
}
