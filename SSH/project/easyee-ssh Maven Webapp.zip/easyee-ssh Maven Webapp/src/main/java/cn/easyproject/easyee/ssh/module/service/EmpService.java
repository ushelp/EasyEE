package cn.easyproject.easyee.ssh.module.service;

import cn.easyproject.easyee.ssh.module.criteria.EmpCriteria;
import cn.easyproject.easyee.ssh.module.entity.Emp;
import cn.easyproject.easyee.ssh.base.util.PageBean;
/**
 * 
 * @author easyproject.cn
 * @version 1.0
 *
 */
public interface EmpService {
	public void add(Emp emp);
	public void delete(String[] empnos);
	public void delete(Integer empno);
	public void update(Emp emp);
	public Emp get(Integer empno);
	public void findByPage(PageBean pageBean,EmpCriteria empCriteria);
	public int findMaxPage(int rowPerPage);
}
