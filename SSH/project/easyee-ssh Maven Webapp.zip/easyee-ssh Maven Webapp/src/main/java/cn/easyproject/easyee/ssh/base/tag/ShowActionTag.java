package cn.easyproject.easyee.ssh.base.tag;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Set;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;
/**
 * EasySSH使用的显示控制标签，如果action不在用户权限范围内，则不显示内容
 * @author easyproject.cn
 * @version 1.0
 *
 */
public class ShowActionTag extends SimpleTagSupport{

	private String action; // “显示动作”名称
	
	@SuppressWarnings("unchecked")
	@Override
	public void doTag() throws JspException, IOException {
		// 如果为空不检测
		if(action==null||action.trim().length()==0){
			return;
		}
		// 获取用户所有的操作权限
		Set<String> operations = (Set<String>) super.getJspContext().getAttribute("operations", PageContext.SESSION_SCOPE);
		// 权限验证通过
		if(operations!=null&&operations.contains(action)){
			StringWriter buffer = new StringWriter();
			getJspBody().invoke(buffer); //执行JSP标签体得到标签体的内容
			//输出标签体内容
			getJspContext().getOut().write(buffer.toString());
		}
	}

	public void setAction(String action) {
		this.action = action;
	}
	
	
	
}
