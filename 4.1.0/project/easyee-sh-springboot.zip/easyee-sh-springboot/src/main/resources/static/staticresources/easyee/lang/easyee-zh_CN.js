/**
 * EasyEE 资源国际化文件-zh_CN 简体中文
 */

if(EasyEE){
	EasyEE.msg={
			failure:"操作失败，请稍后再试，或联系管理员",
			timeout:"登录超时，请重新登录！",
			
			ajaxNotFound:"地址无法找到，请联系管理员",
			ajaxServerError:"服务器错误，请稍后再试，或联系管理员",
			ajaxOtherError:"请求错误！",
			
			serverError:"操作失败，请稍后再试，或联系管理员"
	}
}